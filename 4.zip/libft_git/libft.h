#ifndef LIBFT_H
# define LIBFT_H

#include <stddef.h>
#include <stdlib.h>

int	ft_isdigit(int a);

int	ft_isalpha(int a);

int	ft_isprint(int a);

int	ft_isascii(int a);

int	ft_isalnum(int a);

size_t	ft_strlen(const char *s);

char	*ft_strchr(const char *s, int c);

int	ft_strncmp(const char *s1, const char *s2, size_t n);

size_t	ft_strlcat(char *dst, const char *src, size_t size);

char	*ft_strnstr(const char *big, const char *little, size_t len);

void *ft_memchr(const void *s, int c, size_t n);

void *ft_memset(void *s, int c, size_t n);

void *ft_memcpy(void *dest, const void *src, size_t n);

void *ft_memmove(void *dest, const void *src, size_t n);

void ft_bzero(void *s, size_t n);

char *ft_strjoin(char const *s1, char const *s2);

#endif