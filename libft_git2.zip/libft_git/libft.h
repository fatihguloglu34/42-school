#ifndef LIBFT_H
# define LIBFT_H
#include <stddef.h>

int	ft_isdigit(int a);
int	ft_isalpha(int a);
int	ft_isprint(int a);
int	ft_isascii(int a);
int	ft_isalnum(int a);
size_t	ft_strlen(const char *s);
char	*ft_strchr(const char *s, int c);
int	ft_strncmp(const char *s1, const char *s2, size_t n);
size_t	ft_strlcat(char *dst, const char *src, size_t size);


#endif