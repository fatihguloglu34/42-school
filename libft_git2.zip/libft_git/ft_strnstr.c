/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fguloglu <fguloglu@student.42istanbul.c    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/03 17:41:20 by fguloglu          #+#    #+#             */
/*   Updated: 2026/08/11 20:08:45 by fguloglu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t ft_strnstr(const char *big, const char *little, size_t len)
{
	size_t i;
	size_t j;
	
	i = 0;
	j = 0;
	
	if(little[0] == '\0')
		return((char *)big);
	while ()
	{
		/* code */
	}
	
	return(NULL);
}
