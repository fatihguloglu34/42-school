*This project has been created as part of the 42 curriculum by fguloglu.*

# Libft

## Description

Libft is the first library project in the 42 curriculum.

The goal of this project is to recreate several standard C library functions and to understand how these functions work internally. In addition to the standard functions, the project includes extra utility functions for string and memory manipulation, as well as functions for working with linked lists.

At the end of the project, all functions are compiled into a static library called `libft.a`, which can be reused in future C projects.

## Library Content

The project is divided into three main parts.

### Part 1 - Libc Functions

This part contains reimplementations of standard C library functions.

Examples:

* `ft_isalpha`
* `ft_isdigit`
* `ft_isalnum`
* `ft_isascii`
* `ft_isprint`
* `ft_strlen`
* `ft_memset`
* `ft_bzero`
* `ft_memcpy`
* `ft_memmove`
* `ft_strlcpy`
* `ft_strlcat`
* `ft_toupper`
* `ft_tolower`
* `ft_strchr`
* `ft_strrchr`
* `ft_strncmp`
* `ft_memchr`
* `ft_memcmp`
* `ft_strnstr`
* `ft_atoi`
* `ft_calloc`
* `ft_strdup`

### Part 2 - Additional Functions

This part contains additional useful functions that are not directly part of the standard C library.

* `ft_substr`
* `ft_strjoin`
* `ft_strtrim`
* `ft_split`
* `ft_itoa`
* `ft_strmapi`
* `ft_striteri`
* `ft_putchar_fd`
* `ft_putstr_fd`
* `ft_putendl_fd`
* `ft_putnbr_fd`

These functions provide additional tools for string manipulation, memory management and output operations.

### Part 3 - Linked List Functions

The final part introduces linked lists using the `t_list` structure.

```c
typedef struct s_list
{
	void			*content;
	struct s_list	*next;
}					t_list;
```

The `content` member stores the data of the node, while `next` stores the address of the next node in the list.

The following functions are implemented to manipulate linked lists:

* `ft_lstnew`
* `ft_lstadd_front`
* `ft_lstsize`
* `ft_lstlast`
* `ft_lstadd_back`
* `ft_lstdelone`
* `ft_lstclear`
* `ft_lstiter`
* `ft_lstmap`

## Instructions

Clone the repository and enter the project directory:

```bash
git clone <repository_url>
cd libft
```

Compile the library using:

```bash
make
```

This will create:

```text
libft.a
```

Other available Makefile commands are:

```bash
make clean
```

Removes object files.

```bash
make fclean
```

Removes object files and `libft.a`.

```bash
make re
```

Removes all compiled files and recompiles the library.

The project is compiled using:

```text
-Wall -Wextra -Werror
```

## Usage

Include the header in your C program:

```c
#include "libft.h"
```

Compile your program together with the library:

```bash
cc main.c libft.a -o program
```

Then run it:

```bash
./program
```

## Resources

The following resources were useful while working on this project:

* C manual pages (`man`)
* 42 Libft subject
* 42 Norm documentation
* C standard library documentation
* Peer discussions and evaluations

### AI Usage

AI was used as a learning and support tool during the project.

It was mainly used for:

* Understanding the purpose and behavior of C functions
* Explaining concepts such as pointers, memory allocation and linked lists
* Understanding compilation and Makefile concepts
* Reviewing errors and helping understand why they occurred
* Clarifying the 42 Norm and project requirements

The implementation and understanding of the project functions were developed as part of the learning process.
