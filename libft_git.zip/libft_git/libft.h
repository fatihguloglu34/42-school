#ifndef LIBFT_H
# define LIBFT_H

int	ft_isdigit(int a);
int	ft_isalpha(int a);
int	ft_isprint(int a);
int	ft_isascii(int a);
int	ft_isalnum(int a);

#endif